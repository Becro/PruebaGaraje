package com.adrian.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Set;

import com.adrian.dtos.CursoDTO;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;
import lombok.ToString;



@Entity
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Table(name="CURSO")
public class Curso implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_curso")
    private Long idCurso;
    @Column(name ="nombre")
    @NonNull
    private String nombre;
    @Column(name="fecha_inicio")
    @NonNull
    private LocalDateTime fechaInicio;
    @Column(name="fechaFin")
    @Temporal(TemporalType.TIMESTAMP)
    @NonNull
    private LocalDateTime fechaFin;
    @NonNull
    @Column(name="max_alumnos")
    private Integer maxAlumnos;
    @Column(name="fecha_Registro")
    @NonNull
    @Temporal(TemporalType.TIMESTAMP)
    private LocalDateTime fechaRegistro;
    @ManyToMany(mappedBy="cursos",fetch =FetchType.LAZY)
    private Set<Alumno>alumnos;
    
    
    public Curso(CursoDTO dto) {
    	Optional.ofNullable(dto.getIdCurso()).ifPresent(this::setIdCurso);
    	this.nombre=dto.getNombre();
    	this.fechaInicio=dto.getFechaInicio();
    	this.fechaFin=dto.getFechaFin();
    	this.maxAlumnos=dto.getMaxAlumnos();
    	this.fechaRegistro=dto.getFechaRegistro();    	
    }
    
    public boolean equals(Curso curso) {
    	boolean equals = false;  	
    	
    	if(this.nombre.equals(curso.getNombre()) && this.fechaInicio.isEqual(curso.getFechaInicio())&&
    		this.fechaFin.isEqual(curso.getFechaFin()) && this.maxAlumnos == curso.getMaxAlumnos() &&
    		this.fechaRegistro.isEqual(curso.getFechaRegistro())) {
    		equals = true;
    	}
    	
    	return equals;
    }
}
