package com.adrian.model;

import java.io.Serializable;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="CURSO_ALUMNO")
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CursoAlumno implements Serializable {

		@EmbeddedId
		private CursoAlumnoId id;
		
	  	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	  	@MapsId("cursoId")
	  	@JoinColumn(name="id_curso")
	    private Curso cursoId;
	  	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	  	@MapsId("alumnoId")
	  	@JoinColumn(name="id_alumno")
	    private Alumno alumnoId;
	  	@Column(name="fecha_inscripcion")
	    @Temporal(TemporalType.TIMESTAMP)
	    private LocalDateTime fechaInscripcion;
	  	@Column(name="fecha_baja")
	    @Temporal(TemporalType.TIMESTAMP)
	    private LocalDateTime fechaBaja;
}
