package com.adrian.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Set;

import com.adrian.dtos.AlumnoDTO;


import jakarta.persistence.JoinColumn;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Setter;
import lombok.ToString;


@Entity 
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Table(name="ALUMNO")
public class Alumno implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_alumno")
    private Long idAlumno;
    @NonNull
    @Column(name="nombre")
    private String nombre;
    @Column(name="apellido")
    @NonNull
    private String apellido;
    @Column(name="documento")    
    private String documento;
    @Column(name="fecha_nacimiento")
    @Temporal(TemporalType.TIMESTAMP)
    @NonNull
    private LocalDateTime fechaNacimiento;
    @Column(name="fecha_Registro")
    @Temporal(TemporalType.TIMESTAMP)
    private LocalDateTime fechaRegistro;
    @ManyToMany (fetch =FetchType.LAZY)
    @JoinTable(name="curso_alumno",joinColumns = {@JoinColumn(name = "alumno_Id")},
    inverseJoinColumns = @JoinColumn(name = "curso_id"))
    private Set<Curso>cursos;
   
    
    
    public Alumno(AlumnoDTO dto) {    	
		Optional.ofNullable(dto.getIdAlumno()).ifPresent(this::setIdAlumno);
		this.nombre=dto.getNombre();
		this.apellido=dto.getApellido();
		this.documento=dto.getDocumento();
		this.fechaNacimiento=dto.getFechaNacimiento();
		this.fechaRegistro=dto.getFechaRegistro();		
    }
}
