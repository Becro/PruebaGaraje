package com.adrian.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.adrian.dtos.AlumnoDTO;
import com.adrian.dtos.CursoDTO;
import com.adrian.model.Alumno;
import com.adrian.model.Curso;


@Service
public interface CursoService {

	CursoDTO anyadirCurso(CursoDTO curso);
	Curso guardarCurso(Curso curso);
	CursoDTO actualizarCurso(CursoDTO curso);
	Long eliminarCurso(CursoDTO curso);
	CursoDTO eliminarCurso(Long id);
	CursoDTO consultarCurso(Long id);
	Curso consultaCurso(CursoDTO cursoDto);
	Curso consulta(Long id);
	List<CursoDTO> consultaCursosPorNombre(String nombre);
	List<CursoDTO> consultaCursosPorFechaInicio(LocalDateTime fechaInicio);
	List<CursoDTO> consultaCursosPorFechaFin(LocalDateTime fechaFin);	
	CursoDTO eliminarAlumnoDeCurso(Long idCurso, Long idAlumno);
}
