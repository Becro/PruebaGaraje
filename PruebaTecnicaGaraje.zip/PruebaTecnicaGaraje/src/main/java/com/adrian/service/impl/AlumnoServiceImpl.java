package com.adrian.service.impl;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.dao.DataAccessException;

import com.adrian.dtos.AlumnoDTO;
import com.adrian.dtos.CursoDTO;
import com.adrian.model.Alumno;
import com.adrian.model.Curso;
import com.adrian.repository.AlumnoRepository;
import com.adrian.service.AlumnoService;
import com.adrian.service.CursoService;

public class AlumnoServiceImpl implements AlumnoService {

	@Autowired
	AlumnoRepository repository;
	@Autowired
	@Lazy
	CursoService cursoService;

	@Override
	public AlumnoDTO anyadirAlumno(AlumnoDTO alumnoDto) {
		
		boolean valido = compruebaValidez(alumnoDto);	
		if(valido) {
		Alumno alumno = new Alumno(alumnoDto);
		alumno.setCursos(this.getCursosByDtoSet(alumnoDto.getCursos()));
		try {			
			repository.save(alumno);
			
		} catch (DataAccessException ex) {
			ex.printStackTrace();
			return null;
		 	}
		}
		return alumnoDto;
	}

	private boolean compruebaValidez(AlumnoDTO alumnoDto) {
		boolean valido=true;
		LocalDateTime fechaActual = LocalDateTime.now();
		Long anyoAlumno = ChronoUnit.YEARS.between(fechaActual, alumnoDto.getFechaNacimiento());
		if(anyoAlumno == null || anyoAlumno <18) {
			valido=false;
		}		
		if(alumnoDto.getNombre()==null || alumnoDto.getNombre().isEmpty() || alumnoDto.getNombre().length()>3 ) {
			valido=false;
		}		
		if(alumnoDto.getApellido()==null || alumnoDto.getApellido().isEmpty() || alumnoDto.getApellido().length()>2 ) {
			valido=false;
		}
		if(registroRepetido(alumnoDto)) {
			valido=false;
		}
		
		return valido;
	}

	private boolean registroRepetido(AlumnoDTO alumnoDto) {		
		return repository.findByDocumento(alumnoDto.getDocumento())!=null;
	}

	@Override
	public AlumnoDTO actualizarAlumno(AlumnoDTO alumno) {
			Alumno alumnoActualizar = this.consultaAlumno(alumno.getIdAlumno());
		try {
			repository.saveAndFlush(alumnoActualizar);
		} catch (DataAccessException ex) {
			ex.printStackTrace();
			return null;
		}
		return alumno;
	}

	@Override
	public Long eliminarAlumno(Long id) {
		Alumno alumno =this.consultaAlumno(id);
		try {
		repository.delete(alumno);
		}catch(DataAccessException ex) {
			ex.printStackTrace();
			return null;
		}
		return id;
	}

	@Override
	public AlumnoDTO consulta(Long id) {
		
		try {
		 Alumno alumno = this.consultaAlumno(id);
		 AlumnoDTO dto = new AlumnoDTO(alumno);
		 dto.setCursos(this.getCursosDTOByCursosSet(alumno.getCursos()));
		 return dto;
		}catch(DataAccessException ex) {ex.printStackTrace();}
		return null;
	}

	@Override
	public List<AlumnoDTO> consultaPorFechaNacimiento(LocalDateTime fechaNacimiento) {
		
		List<AlumnoDTO>listDto = new ArrayList<AlumnoDTO>();	
		try {
		List<Alumno> alumnos =repository.findByFechaNacimiento(fechaNacimiento);	
	
		
			alumnos.forEach(alumno -> {
			    AlumnoDTO dto = new AlumnoDTO(alumno);
			    Set<CursoDTO> cursos = this.getCursosDTOByCursosSet(alumno.getCursos());
			    dto.setCursos(cursos);
			    listDto.add(dto);
			});	
		}catch(DataAccessException ex) {ex.printStackTrace();}
		
		return listDto;
	}

	@Override
	public List<AlumnoDTO> consultaPorNombre(String nombre) {
		List<AlumnoDTO>listDto = new ArrayList<AlumnoDTO>();	
		try {
		List<Alumno> alumnos =repository.findByNombre(nombre);		
			alumnos.forEach(alumno -> {
			    AlumnoDTO dto = new AlumnoDTO(alumno);
			    Set<CursoDTO> cursos = this.getCursosDTOByCursosSet(alumno.getCursos());
			    dto.setCursos(cursos);
			    listDto.add(dto);
			});	
		}catch(DataAccessException ex) {ex.printStackTrace();}
		
		return listDto;
	}
	
	@Override
	public List<AlumnoDTO> consultaPorCurso(CursoDTO cursoDto) {
		try {
	   Curso curso = cursoService.consulta(cursoDto.getIdCurso());
	   List<AlumnoDTO> alumnoList =new ArrayList<AlumnoDTO>();
	   alumnoList.addAll(cursoDto.getAlumnos());
	   return alumnoList;
		}catch(DataAccessException ex) {
			ex.printStackTrace();
		}
		return new ArrayList<>();
	}

	private Set<Curso> getCursosByDtoSet(Set<CursoDTO> cursosDto) {
		Set<Curso> cursos = new HashSet<Curso>();
		if (cursosDto != null) {
			cursosDto.forEach(dto -> cursos.add(new Curso(dto)));
		}
		return cursos;

	}

	@Override
	public Alumno consultaAlumno(Long id) {
		
		return repository.findById(id).get();
	}
	
	
	
	private Set<CursoDTO> getCursosDTOByCursosSet(Set<Curso> cursos) {
		Set<CursoDTO> cursosDto = new HashSet<CursoDTO>();
		if (cursos != null) {
			cursos.forEach(c -> cursosDto.add(new CursoDTO(c)));
		}
		return cursosDto;

	}

	@Override
	public AlumnoDTO consultaPorDocumento(String documento) {		
		Alumno alumno = repository.findByDocumento(documento);
		AlumnoDTO dto = new AlumnoDTO(alumno);
		dto.setCursos(this.getCursosDTOByCursosSet(alumno.getCursos()));
		return dto;
		
	}

	@Override
	public AlumnoDTO actualizarAlumno(Alumno alumno) {
		repository.save(alumno);
		AlumnoDTO dto = new AlumnoDTO(alumno);
		dto.setCursos(this.getCursosDTOByCursosSet(alumno.getCursos()));		
		return dto;
	}

	@Override
	public AlumnoDTO altaEnCurso(List<Long> idCursos, Long idAlumno, AlumnoDTO alumno) {
		Alumno alu= this.consultaAlumno(idAlumno);
		alumno.setIdAlumno(alu.getIdAlumno());		
		for(Long id: idCursos) {
			Curso curso = cursoService.consulta(id);
			curso.getAlumnos().add(alu);
			cursoService.guardarCurso(curso);			
		}		
		
		return alumno;
	}

}
