package com.adrian.service;


import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.adrian.dtos.AlumnoDTO;
import com.adrian.dtos.CursoDTO;
import com.adrian.model.Alumno;



@Service
public interface AlumnoService {

	AlumnoDTO anyadirAlumno(AlumnoDTO alumno);
	AlumnoDTO actualizarAlumno(AlumnoDTO alumno);
	AlumnoDTO actualizarAlumno(Alumno alumno);
	Long eliminarAlumno(Long id);
	AlumnoDTO consulta(Long id);
	Alumno consultaAlumno(Long id);
	AlumnoDTO consultaPorDocumento(String documento);
	List<AlumnoDTO> consultaPorFechaNacimiento(LocalDateTime fechaNacimiento);
	List<AlumnoDTO> consultaPorNombre(String nombre); 
	List<AlumnoDTO> consultaPorCurso(CursoDTO cursoDto);
	AlumnoDTO altaEnCurso(List<Long> idCursos, Long idAlumno, AlumnoDTO alumno);
	
	
	
}
