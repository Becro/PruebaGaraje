package com.adrian.service.impl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.dao.DataAccessException;

import com.adrian.dtos.AlumnoDTO;
import com.adrian.dtos.CursoDTO;
import com.adrian.model.Alumno;
import com.adrian.model.Curso;
import com.adrian.repository.CursoRepository;
import com.adrian.service.AlumnoService;
import com.adrian.service.CursoService;

public class CursoServiceImpl implements CursoService {

	@Autowired
	private CursoRepository repository;
	@Autowired
	@Lazy
	private AlumnoService alumnoService;
	
	@Override
	public CursoDTO anyadirCurso(CursoDTO cursoDto) {
		boolean valido = validarCurso(cursoDto);
		if(valido) {			
			Curso curso = new Curso(cursoDto);
			Set<Alumno>alumnos = getAlumnosFromDto(cursoDto.getAlumnos());
			curso.setAlumnos(alumnos);
			try {
			repository.save(curso);			
			}catch(DataAccessException ex) {ex.printStackTrace();}
		}		
		
		return cursoDto;
	}

	private Set<Alumno> getAlumnosFromDto(Set<AlumnoDTO> alumnosDto) {
		Set<Alumno> alumnos = new HashSet<Alumno>();
		if(alumnosDto!=null) {
			alumnosDto.forEach(alumno -> alumnos.add(new Alumno(alumno)));
		}
		
		return alumnos;
	}

	@Override
	public CursoDTO actualizarCurso(CursoDTO cursoDto) {
		Curso curso = new Curso(cursoDto);
		curso.setAlumnos(getAlumnosFromDto(cursoDto.getAlumnos()));
		try {
		repository.saveAndFlush(curso);
		}catch(DataAccessException ex) {ex.printStackTrace();}
		return cursoDto;
	}

	@Override
	public Long eliminarCurso(CursoDTO cursoDto) {
		Curso curso = new Curso(cursoDto);
		if(curso.getAlumnos().isEmpty()) {
			try {
				repository.delete(curso);
				return cursoDto.getIdCurso();
			}catch(DataAccessException ex) {ex.printStackTrace();}
		}
		return null;
	}

	@Override
	public Curso consultaCurso(CursoDTO cursoDto) {		
		return this.consulta(cursoDto.getIdCurso());
	}

	@Override
	public CursoDTO consultarCurso(Long id) {
		Curso curso = this.consulta(id);
		CursoDTO dto = new CursoDTO(curso);
		dto.setAlumnos(this.getAlumnosDtoFromObject(curso.getAlumnos()));
		return dto;
	}

	@Override
	public Curso consulta(Long id) {
			return repository.findById(id).get();
	}

	@Override
	public List<CursoDTO> consultaCursosPorNombre(String nombre) {
		List<CursoDTO> cursosDto= new ArrayList<CursoDTO>();
		List<Curso> cursos = repository.findByNombre(nombre);
		cursos.forEach(curso ->{
			CursoDTO dto = new CursoDTO(curso);
			Set<AlumnoDTO>alumnos = this.getAlumnosDtoFromObject(curso.getAlumnos());
			dto.setAlumnos(alumnos);
			cursosDto.add(dto);
		});
		
		return cursosDto;
	}

	@Override
	public List<CursoDTO> consultaCursosPorFechaInicio(LocalDateTime fechaInicio) {
		List<CursoDTO> cursosDto= new ArrayList<CursoDTO>();
		List<Curso> cursos = repository.findByFechaInicio(fechaInicio);
		cursos.forEach(curso ->{
			CursoDTO dto = new CursoDTO(curso);
			Set<AlumnoDTO>alumnos = this.getAlumnosDtoFromObject(curso.getAlumnos());
			dto.setAlumnos(alumnos);
			cursosDto.add(dto);
		});
		
		return cursosDto;
			
	}

	private Set<AlumnoDTO> getAlumnosDtoFromObject(Set<Alumno> alumnos) {
		Set<AlumnoDTO> alumnosDto = new HashSet<AlumnoDTO>();
		if(alumnos!=null) {
			alumnos.forEach(alumno -> alumnosDto.add(new AlumnoDTO(alumno)));
		}
		return alumnosDto;
	}

	public boolean validarCurso(CursoDTO dto) {
		boolean valido=true;
		if(dto.getNombre()==null || dto.getNombre().isEmpty() || dto.getNombre().length()<3) {
			valido=false;
		}
		if(dto.getMaxAlumnos()==null || dto.getMaxAlumnos()==0) {
			valido=false;
		}
		
		if(dto.getFechaInicio()==null || !dto.getFechaInicio().isAfter(LocalDateTime.now())) {
			valido=false;
		}
		if(dto.getFechaFin()==null || !dto.getFechaFin().isBefore(LocalDateTime.now())) {
			valido=false;
		}
		if(cursoRepetido(dto)) {
			valido=false;
		}
		
		return valido;
	}

	private boolean cursoRepetido(CursoDTO dto) {
		boolean repetido = false;
		Curso cursoActual = new Curso(dto);
		List<Curso> todosLosCursos = repository.findAll();	
		for(Curso c: todosLosCursos) {
			if(cursoActual.equals(c)) {
				repetido=true;
			}
		}		
		
		return repetido;
	}

	@Override
	public List<CursoDTO> consultaCursosPorFechaFin(LocalDateTime fechaFin) {
		List<CursoDTO> cursosDto= new ArrayList<CursoDTO>();
		List<Curso> cursos = repository.findByFechaFin(fechaFin);
		cursos.forEach(curso ->{
			CursoDTO dto = new CursoDTO(curso);
			Set<AlumnoDTO>alumnos = this.getAlumnosDtoFromObject(curso.getAlumnos());
			dto.setAlumnos(alumnos);
			cursosDto.add(dto);
		});		
		return cursosDto;
	}

	@Override
	public CursoDTO eliminarAlumnoDeCurso(Long idCurso, Long idAlumno) {
		//primero comprobar que el alumno está en el curso
		boolean cursaCurso = false;		
		Curso curso = this.consulta(idCurso);
		Alumno alumno = this.alumnoService.consultaAlumno(idAlumno);
		CursoDTO dto = new CursoDTO(curso);
		dto.setAlumnos(this.getAlumnosDtoFromObject(curso.getAlumnos()));
			if(curso.getAlumnos().contains(alumno)) {
				cursaCurso= true;
			}	
		
		//eliminar alumno del curso y curso del alumno
			if(cursaCurso) {
				curso.getAlumnos().remove(alumno);
				alumno.getCursos().remove(curso);
				//guardar datos
				this.repository.save(curso);				
				this.alumnoService.actualizarAlumno(alumno);
				
			}		
		
		return dto;
	}

	@Override
	public Curso guardarCurso(Curso curso) {
		 this.repository.save(curso);
		 return curso;
	}

	@Override
	public CursoDTO eliminarCurso(Long id) {
		Curso curso = this.consulta(id);
		CursoDTO dto = new CursoDTO(curso);
		dto.setAlumnos(this.getAlumnosDtoFromObject(curso.getAlumnos()));
		this.eliminarCurso(dto);
		return dto;
	}




}
