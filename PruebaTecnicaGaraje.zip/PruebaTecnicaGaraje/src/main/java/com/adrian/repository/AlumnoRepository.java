package com.adrian.repository;

import java.time.LocalDateTime;
import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.adrian.model.Alumno;

@Repository
public interface AlumnoRepository extends JpaRepository<Alumno, Long>{

	List<Alumno> findByNombre(String nombre);
	List<Alumno>findByFechaNacimiento(LocalDateTime fechaNacimiento);
	Alumno findByDocumento(String documento);
}
