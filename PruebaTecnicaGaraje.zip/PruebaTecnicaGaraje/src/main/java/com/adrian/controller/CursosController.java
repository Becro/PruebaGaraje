package com.adrian.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.adrian.dtos.AlumnoDTO;
import com.adrian.dtos.CursoDTO;
import com.adrian.dtos.CursoDTO;
import com.adrian.service.CursoService;

@RestController("/cursos")
public class CursosController {

	@Autowired
	private CursoService cursoService;
	

	 @PostMapping("/anyadirCurso")
    public ResponseEntity<CursoDTO> anyadirCurso(@RequestBody CursoDTO curso) {
        CursoDTO dto = cursoService.anyadirCurso(curso);
        return new ResponseEntity<>(dto, HttpStatus.CREATED);
    }	
	
	 @PutMapping("/actualizarCurso")
	    public ResponseEntity<CursoDTO> actualizarCurso(@PathVariable Long id, @RequestBody CursoDTO Curso) {
	        Curso.setIdCurso(id);
	        CursoDTO dto = cursoService.actualizarCurso(Curso);
	        return new ResponseEntity<>(dto, HttpStatus.OK);
	    }
	 @DeleteMapping("/cursos/{id}")
	    public ResponseEntity<Long> eliminarCurso(@PathVariable Long id) {
	        cursoService.eliminarCurso(id);
	        return new ResponseEntity<Long>(id,HttpStatus.NO_CONTENT);
	    }
	
	@GetMapping("/consultaCursos/{id}")
    public ResponseEntity<CursoDTO> consultaCurso(@PathVariable Long id) {
        CursoDTO curso = cursoService.consultarCurso(id);
        return new ResponseEntity<>(curso, HttpStatus.OK);
    }
	
	@GetMapping("/consultaCursos/")
    public ResponseEntity<List<CursoDTO>> consultaCurso(@RequestParam(required = true) String nombre) {
        List<CursoDTO> cursoList = cursoService.consultaCursosPorNombre(nombre);
        return new ResponseEntity<>(cursoList, HttpStatus.OK);
    }
		
	@GetMapping("/consultaCursosFechaInicio/")
    public ResponseEntity<List<CursoDTO>> consultaCursoFechaInicio(
    	@RequestParam(required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDateTime fechaInicio) {
        List<CursoDTO> cursoList = cursoService.consultaCursosPorFechaInicio(fechaInicio);
        return new ResponseEntity<>(cursoList, HttpStatus.OK);
    }
	
	@GetMapping("/consultaCursosFechaFin/")
    public ResponseEntity<List<CursoDTO>> consultaCursoFechaFin(
    	@RequestParam(required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDateTime fechaFin) {
        List<CursoDTO> cursoList = cursoService.consultaCursosPorFechaFin(fechaFin);
        return new ResponseEntity<>(cursoList, HttpStatus.OK);
    }
	
	@DeleteMapping
	public ResponseEntity<CursoDTO> eliminarAlumnoDeCurso(
			@PathVariable Long idCurso, @PathVariable Long idAlumno) {
	        CursoDTO dto = cursoService.eliminarAlumnoDeCurso(idCurso, idAlumno);
	        return new ResponseEntity<>(dto, HttpStatus.OK);
	    }
}
