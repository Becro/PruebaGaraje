package com.adrian.controller;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.adrian.dtos.AlumnoDTO;
import com.adrian.dtos.CursoDTO;
import com.adrian.service.AlumnoService;

@RestController("/alumnos")
public class AlumnoController {

	   @Autowired
	    private AlumnoService alumnoService;	    
	   

	    @PostMapping("/anyadir")
	    public ResponseEntity<AlumnoDTO> anyadirAlumno(@RequestBody AlumnoDTO alumno) {
	        AlumnoDTO dto = alumnoService.anyadirAlumno(alumno);
	        return new ResponseEntity<>(dto, HttpStatus.CREATED);
	    }

	    @PutMapping("/actualizar")
	    public ResponseEntity<AlumnoDTO> actualizarAlumno(@PathVariable Long id, @RequestBody AlumnoDTO alumno) {
	        alumno.setIdAlumno(id);
	        AlumnoDTO dto = alumnoService.actualizarAlumno(alumno);
	        return new ResponseEntity<>(dto, HttpStatus.OK);
	    }

	    @DeleteMapping("/alumnos/{id}")
	    public ResponseEntity<Long> eliminarAlumno(@PathVariable Long id) {
	        alumnoService.eliminarAlumno(id);
	        return new ResponseEntity<Long>(id,HttpStatus.NO_CONTENT);
	    }

	    @GetMapping("/alumnos/{id}")
	    public ResponseEntity<AlumnoDTO> consultaAlumno(@PathVariable Long id) {
	        AlumnoDTO alumno = alumnoService.consulta(id);
	        return new ResponseEntity<>(alumno, HttpStatus.OK);
	    }

	    @GetMapping("/alumnos/consultaFechaNacimiento")
	    public ResponseEntity<List<AlumnoDTO>> consultaAlumnosFechaNacimiento(
	            @RequestParam(required = true) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDateTime fechaNacimiento) {
	        List<AlumnoDTO> alumnos;
	        if (fechaNacimiento != null) {
	            alumnos = alumnoService.consultaPorFechaNacimiento(fechaNacimiento);	        
	        } else {
	            alumnos = new ArrayList<AlumnoDTO>();
	        }
	        return new ResponseEntity<>(alumnos, HttpStatus.OK);
	    }
	    
	    @GetMapping("/alumnos/consultaNombre")
	    public ResponseEntity<List<AlumnoDTO>> consultaAlumnosNombre(
	            @RequestParam(required = true) String nombre) {
	        List<AlumnoDTO> alumnos;
	        if (nombre != null && !nombre.isEmpty()) {
	            alumnos = alumnoService.consultaPorNombre(nombre);
	        } else {
	            alumnos = new ArrayList<AlumnoDTO>();
	        }
	        return new ResponseEntity<>(alumnos, HttpStatus.OK);
	    }
	    
	    @GetMapping("/alumnos/documento")
	    public ResponseEntity<AlumnoDTO> consultaAlumnosDocumento(
	            @RequestParam(required = true) String documento) {
	    	AlumnoDTO alumno = alumnoService.consultaPorDocumento(documento);
	        return new ResponseEntity<>(alumno, HttpStatus.OK);
	    }
	    
	    @GetMapping("/alumnos/consultaPorCurso")
	    public ResponseEntity<List<AlumnoDTO>> consultaPorCurso(
	    		@PathVariable Long id, @RequestBody CursoDTO curso) {
	    	 List<AlumnoDTO> alumnos;
	    	 if(curso!=null) {
	    		 curso.setIdCurso(id);
	    		 alumnos= alumnoService.consultaPorCurso(curso);
	    	 }else {
	    		 alumnos=new ArrayList<>();
	    	 }
	        return new ResponseEntity<>(alumnos, HttpStatus.OK);
	    }
	    @PostMapping("/alumnos/altaEnCurso")
	    public ResponseEntity<AlumnoDTO> altaEnCurso(
	    		@RequestBody List<Long> idCursos,
	    		@PathVariable Long idAlumno, @RequestBody AlumnoDTO alumno){	    	
	    		alumno=alumnoService.altaEnCurso(idCursos,idAlumno,alumno);	    	
	    	return new ResponseEntity<>(alumno, HttpStatus.OK);
	    }
}
