package com.adrian.dtos;

import java.time.LocalDateTime;
import java.util.Set;

import com.adrian.model.Alumno;
import com.adrian.model.Curso;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class AlumnoDTO {

	
	    private Long idAlumno;	 
	    private String nombre;
	    private String apellido;	    
	    private String documento;	    
	    private LocalDateTime fechaNacimiento;	   
	    private LocalDateTime fechaRegistro;	    
	    private Set<CursoDTO>cursos;
	    
	    public AlumnoDTO(Alumno alumno) {
	    	this.idAlumno = alumno.getIdAlumno();
	    	this.nombre=alumno.getNombre();
	    	this.apellido=alumno.getApellido();
	    	this.documento=alumno.getDocumento();
	    	this.fechaNacimiento=alumno.getFechaNacimiento();
	    	this.fechaRegistro = alumno.getFechaRegistro();
	    }
}
