package com.adrian.dtos;

import java.time.LocalDateTime;
import java.util.Set;

import com.adrian.model.Alumno;
import com.adrian.model.Curso;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CursoDTO {
	
    private Long idCurso;    
    private String nombre;    
    private LocalDateTime fechaInicio;    
    private LocalDateTime fechaFin;   
    private Integer maxAlumnos;   
    private LocalDateTime fechaRegistro;   
    private Set<AlumnoDTO>alumnos;
    
    public CursoDTO(Curso curso) {
    	this.idCurso=curso.getIdCurso();
    	this.nombre=curso.getNombre();
    	this.maxAlumnos=curso.getMaxAlumnos();
    	this.fechaInicio=curso.getFechaInicio();
    	this.fechaRegistro=curso.getFechaRegistro();
    	
    }
}
